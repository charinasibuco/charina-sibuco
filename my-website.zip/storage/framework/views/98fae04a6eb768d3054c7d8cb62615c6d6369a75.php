<?php $__env->startSection('content'); ?>
<?php echo $__env->make('template.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
	<div class="row">
		<div class="col-xs-6">
			<h2> About Sample Page</h2>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>