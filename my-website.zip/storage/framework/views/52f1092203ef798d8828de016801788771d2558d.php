<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0"/>
    <title><?php echo $__env->yieldContent('title'); ?></title>
     <?php echo $__env->yieldContent('style'); ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/font-awesome.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="<?php echo e(url('js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="<?php echo e(url('js/components.js')); ?>"></script>
    <script src="<?php echo e(url('js/skill-chart.js')); ?>"></script>
    <script src="<?php echo e(url('js/typed.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>