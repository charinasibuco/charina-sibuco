@extends('template.layout')
@section('content')
@include('template.navigation')
<div class="container">
	<div class="row">
		<div class="col-xs-6">
			<h2> About Sample Page</h2>
		</div>
	</div>
</div>
@endsection
