<div class="banner center-position-item">
	<div class="text center-item">
		<span class="title">CHARINA SIBUCO</span><br>
		<span class="sub-title auto_type"></span>
		<hr>
		<hr>
	</div>

</div>
<div class="picture-row">
</div>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4">
			<div id="my-picture" class="center-item center-position-item circle-frame-shadow"></div>
		</div>
		<div class="col-sm-4"></div>
	</div>
</div>
